public void CGLine(float x1, float y1, float x2, float y2) {
    stroke(0);
    line(x1, y1, x2, y2);
}

public boolean outOfBoundary(float x, float y) {
    if (x < 0 || x >= width || y < 0 || y >= height)
        return true;
    return false;
}

public void drawPoint(float x, float y, color c) {
    int index = (int) y * width + (int) x;
    if (outOfBoundary(x, y))
        return;
    pixels[index] = c;
}

public float distance(Vector3 a, Vector3 b) {
    Vector3 c = a.sub(b);
    return sqrt(Vector3.dot(c, c));
}

boolean pnpoly(float x, float y, Vector3[] vertexes) {
    // TODO HW2
    // You need to check the coordinate p(x,v) if inside the vertexes.
    
    int count = 0;
    int n = vertexes.length;
    for(int i = 0; i< n;  i++){
        Vector3 p1, p2;
        p1  =  vertexes[i];
        p2 = vertexes[(i+1)%n];
        if((y<  p1.y) != (y<p2.y)){
          float decision = ( (y - p1.y) * (p2.x - p1.x) ) / (p2.y - p1.y) + p1.x;
          if(x  < decision){
            count ++;
          }
        }
        
    }

    return count%2 ==1;
}

public Vector3[] findBoundBox(Vector3[] v) {    
    // TODO HW2
    // You need to find the bounding box of the vertexes v.

    Vector3 recordminV = new Vector3(0);
    Vector3 recordmaxV = new Vector3(999);
    float minX = Float.POSITIVE_INFINITY, maxX = Float.NEGATIVE_INFINITY;
    float minY = Float.POSITIVE_INFINITY, maxY = Float.NEGATIVE_INFINITY;
    float minZ = Float.POSITIVE_INFINITY, maxZ = Float.NEGATIVE_INFINITY;
    
    for (Vector3 vtx : v) {
        float x = vtx.x, y = vtx.y, z = vtx.z;
    
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
    
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
    
        if (z < minZ) minZ = z;
        if (z > maxZ) maxZ = z;
    }
    recordminV = new Vector3(minX, minY, minZ);
    recordmaxV = new Vector3(maxX, maxY, maxZ);
    Vector3[] result = { recordminV, recordmaxV };
    return result;
}
public boolean inside(Vector3 p, Vector3 a, Vector3 b) {
    return (b.x - a.x)*(p.y - a.y) - (b.y - a.y)*(p.x - a.x) <= 0;
}
Vector3 intersection(Vector3 p, Vector3 q, Vector3 a, Vector3 b) {
    float A1 = q.y - p.y;
    float B1 = p.x - q.x;
    float C1 = A1 * p.x + B1 * p.y;

    float A2 = b.y - a.y;
    float B2 = a.x - b.x;
    float C2 = A2 * a.x + B2 * a.y;

    float det = A1 * B2 - A2 * B1;
    if (Math.abs(det) < 1e-6) {
        return p;
    }

    float x = (B2 * C1 - B1 * C2) / det;
    float y = (A1 * C2 - A2 * C1) / det;

    return new Vector3(x, y, 0);
}
public Vector3[] Sutherland_Hodgman_algorithm(Vector3[] points, Vector3[] boundary) {
   
    for(int i= 0 ; i< boundary.length; i++){
       Vector3 tmp =  boundary[i];
       println("V.x | " + tmp.x + 
       " V.y| "+  tmp.y +  " V.z| " + tmp.z);
       if(i == boundary.length-1){
         println("end");
       }
    }
    ArrayList<Vector3> input = new ArrayList<Vector3>();
    ArrayList<Vector3> output = new ArrayList<Vector3>();
    for (int i = 0; i < points.length; i += 1) {
        input.add(points[i]);
    }

    // TODO HW2
    // You need to implement the Sutherland Hodgman Algorithm in this section.
    // The function you pass 2 parameter. One is the vertexes of the shape "points".
    // And the other is the vertexes of the "boundary".
    // The output is the vertexes of the polygon.
    
    int n  = points.length;
    int bn = boundary.length;
    for(int i = 0; i< bn; i++){
      Vector3 b1 = boundary[i];
      Vector3 b2 = boundary[(i+1)%bn];
      output.clear();
      n = input.size();
      for(int j =0; j< n;j++){
          Vector3 p1 = input.get(j);
          Vector3 p2 = input.get((j+1)%n);
          boolean p1Inside = inside(p1,  b1, b2);
          boolean p2Inside = inside(p2, b1, b2);
          if(p1Inside&& p2Inside){
            output.add(p2);
            
          }
          else if(p1Inside && !p2Inside){
            Vector3 inter = intersection(p1,p2,b1, b2);
            output.add(inter);
          }
          else if(!p1Inside && p2Inside){
            Vector3 inter = intersection(p1,p2,b1, b2);
            output.add(inter);
            output.add(p2);
          }
        
        
      }
      input = new ArrayList<Vector3>(output);
    }
    
    output = input;
    Vector3[] result = new Vector3[output.size()];
    for (int i = 0; i < result.length; i += 1) {
        result[i] = output.get(i);
    }
    
    return result;
}

public float getDepth(float x, float y, Vector3[] vertex) {
    // TODO HW3
    // You need to calculate the depth (z) in the triangle (vertex) based on the
    // positions x and y. and return the z value;
    Vector3 v0 = vertex[1].sub(vertex[0]);
    Vector3 v1 = vertex[2].sub(vertex[0]);
    Vector3 n = Vector3.cross(v0,v1);
    float A = n.x;
    float B = n.y;
    float C = n.z;
    float D = -(A * vertex[0].x + B * vertex[0].y + C * vertex[0].z);

    return -(A*x + B*y + D) / C;
}

float[] barycentric(Vector3 P, Vector4[] verts) {

    Vector3 A = verts[0].homogenized();
    Vector3 B = verts[1].homogenized();
    Vector3 C = verts[2].homogenized();

    // TODO HW4
    // Calculate the barycentric coordinates of point P in the triangle verts using
    // the barycentric coordinate system.


     float denom = (B.x - A.x) * (C.y - A.y) -
                  (B.y - A.y) * (C.x - A.x);

    if (Math.abs(denom) < 1e-6f) {
        return new float[]{0, 0, 0}; // degenerate triangle
    }

    float alpha = ((B.x - P.x) * (C.y - P.y) -
                   (B.y - P.y) * (C.x - P.x)) / denom;

    float beta  = ((C.x - P.x) * (A.y - P.y) -
                   (C.y - P.y) * (A.x - P.x)) / denom;

    float gamma = 1.0f - alpha - beta;

    return new float[]{alpha, beta, gamma};
}
